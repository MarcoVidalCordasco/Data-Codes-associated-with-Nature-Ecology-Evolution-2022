




rm(list = ls()) # Clear all
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
## Libraries

library(openxlsx)
library(ggplot2)
library(ggpubr)
library(gridExtra)
library(analogue)
library(dplyr)



### Open the datasets obtained from the European Modern Pollen Database (EMPD):


Dataset<-readRDS(file = "EMPD_Genus.Rds")

head(Dataset)
PercentageSpecies<- Dataset[,1:476]
head(PercentageSpecies)

MAT.Dataset<- Dataset[,477:479]
head(MAT.Dataset)

MAP.Dataset<- Dataset[,477:480]
head(MAP.Dataset)
######################### GENERATE PREDICTIVE FUNCTIONS

## MEAN ANNUAL TEMPERATURE (MAT)

pred.temp <-wa(PercentageSpecies, MAT.Dataset$T_ann, deshrink= "monotonic")
pred.temp 


##Bootstrap
boot <- bootstrap(pred.temp, n.boot = 500)
performance(boot)

## MEAN ANNUAL PRECIPITATION (MAP)

pred.prep<-wa(PercentageSpecies, MAP.Dataset$P_ann, deshrink= "monotonic")
pred.prep


##Bootstrap
boot <- bootstrap(pred.prep, n.boot = 500)
performance(boot)


###################### APPLY PREDICTIVE FUNCTIONS

Dataset <-readRDS(file = "PredPollen.Rds")

Sites <-Dataset[,1]
Level <-Dataset[,2]
Sites


Dataset <-Dataset[,3:48]
head(Dataset)


### MAT

pred.MAT <- predict(pred.temp, Dataset, tol.dw=TRUE)
pred.MAT

reconPlot(pred.MAT, use.labels = TRUE, display = "bars")


MAT <- as.data.frame(pred.MAT$pred$pred)
MAT$Site <- Sites
MAT$Level <- Level
write.xlsx(MAT, "PredictedMAT2.xlsx")


### MAP

pred.MAP <- predict(pred.prep, Dataset, tol.dw=TRUE)
pred.MAP
reconPlot(pred.MAP, use.labels = TRUE, display = "bars")
MAP <- as.data.frame(pred.MAP$pred$pred)
MAP
MAP$Site <- Sites
MAP$Level <- Level
write.xlsx(MAP, "PredictedMAP2.xlsx")


### Observed vs Predicted values


Dataset <- readRDS(file = "Outputs.Rds")


head(Dataset)

MatPlot <- ggplot(data = Dataset, aes(x = MAT_predicted, y = MAT_observed)) +
  geom_point() +
  stat_smooth(method = "lm") +
  scale_y_continuous(expand = c(0.01, 0)) +
  xlab("Observed MAT (ºC)") +
  ylab("Predicted MAT (ºC)") +
  stat_cor(method = "pearson") +
  theme_classic()


MaPPlot <- ggplot(data = Dataset, aes(x = MAP_predicted, y = MAP_observed)) +
  geom_point() +
  stat_smooth(method = "lm") +
  scale_y_continuous(expand = c(0.01, 0)) +
  xlab("Observed MAP (mm/year)") +
  ylab("Predicted MAP (mm/year)") +
  stat_cor(method = "pearson") +
  theme_classic()

grid.arrange(MatPlot, MaPPlot, ncol=2)



