
################## The script below was written in  Rstudio, so it is  recommended
############ to be run within RStudio.
# SETUP ####
rm(list = ls()) # Clear all
# the following command sets the working directory to the folder where this
# script is located (similar to RStudio menu "Session - Set Working Directory -
# To Source File Location"):
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

## Load libraries

library(dplyr)
library(tidyr)
library(tidyverse)
library(ggplot2)
library(openxlsx)
library(gridExtra)
library(robustbase)
library(rstatix)
library(TSclust)
library(ggdendro)
library(circlize)
library(dendextend)
library(vegan)
library(ggpubr)
library(iNEXT)
library(reshape)
require(Bchron)
library(rcarbon)




#_________________________________________________________________________________
#
## LOAD FUNCTIONS
#
#_______________________________________________


####### Functions to estimate the total biomass of primary consumers from the estimated NPP <log10 (g/m^2/y)>:

## Open the dataset with  the NPP and the herbivore biomass empirical observations:
Dataset <- readRDS(file = "HB_NPP_Dataset.Rds")


## Compute the predictive model. For details, see the script :'HerbivoreBiomassFromNPP.R'
model <- lmrob(logHB~logNPP, data = Dataset)


## Apply the predictive model to estimate the herbivore biomass and the 95% Confidence Interval of the prediction:
Bpc.mean <- function(NPP) 
{
  # Create a new data frame 
  logNPP <- NPP
  Value <- data.frame(logNPP)
  # Compute the mean herbivore biomass with the 95% CI
  Biomass_PC<- as.data.frame(predict(model, newdata = Value, interval = 'confidence'))
  # report the biomass in kg/km^2
  Biomass_PC <-10^(Biomass_PC$fit)
  return(Biomass_PC)
}
Bpc.max <- function(NPP) 
{
  # Create a new data frame 
  logNPP <- NPP
  Value <- data.frame(logNPP)
  # Compute the mean herbivore biomass with the 95% CI
  Biomass_PC<- as.data.frame(predict(model, newdata = Value, interval = 'confidence'))
  # report the biomass in kg/km^2
  Biomass_PC <-10^(Biomass_PC$upr)
  return(Biomass_PC)
}
Bpc.min <- function(NPP)
{
  # Create a new data frame 
  logNPP <- NPP
  Value <- data.frame(logNPP)
  # Compute the mean herbivore biomass with the 95% CI
  Biomass_PC<- as.data.frame(predict(model, newdata = Value, interval = 'confidence'))
  # report the biomass in kg/km^2
  Biomass_PC <-10^(Biomass_PC$lwr)
  return(Biomass_PC)
}

######## Function to transform the NPP expressed in kg/m^2/yr to log10 (g/m^2/y):

log_transform_NPP <- function(x) 
{
  log_transform_NPP <- log10 (as.numeric(x) * 1000)
  return(log_transform_NPP)
}

####### Compute the coefficient of variation

co.var<-function(x) 100*(sd(x,na.rm=TRUE)/mean(x,na.rm=TRUE))

##### Function to estimate the abundance of each herbivore population species in each Stadial/Interstadial (x)

Estimate_Population_Density <- function(x) 
{
  NPP <- log_transform_NPP( sprintf("%.4f", Summary_NPP$NPP[,1][Summary_NPP$Region==x]))
  
  ### Total Herbivore Biomass:
  
  Mean.Biomass <- Bpc.mean (NPP)
  Min.Biomass <- Bpc.min (NPP)
  Max.Biomass <- Bpc.max (NPP)
  
  ### Mean population density (Dens.mean) and the 95% CI (Dens.min and Dens.max) of each herbivore species:
  
  Fauna_BodyMass.df<- as.data.frame(Fauna_BodyMass)
  
  Dens.mean <- (Mean.Biomass / sum(Fauna_BodyMass.df^0.25)) * Fauna_BodyMass.df ^-0.75
  Dens.min <- (Min.Biomass / sum(Fauna_BodyMass.df^0.25)) * Fauna_BodyMass.df ^-0.75
  Dens.max <- (Max.Biomass / sum(Fauna_BodyMass.df^0.25)) * Fauna_BodyMass.df ^-0.75
  
  ## Create a new data frame with the mean population density of each herbivore species, the 95% C.I. of
  ## the estimations and the body size category:
  
  Mean<- Dens.mean[,1]
  Min <- Dens.min [,1]
  Max <- Dens.max [,1]
  
  Herbivore_Density<- as.data.frame (t(rbind(Mean, Min, Max)))
  Herbivore_Density$Species <- Species_List
  Herbivore_Density$BM <-Fauna_BodyMass
  Herbivore_Density$SC_1 <- SizeCategory
  Herbivore_Density$Region <- x
  
  return(Herbivore_Density)
}


#### Function to estimate the Biomass (kg/km^2/yr) of each herbivore population according to the 
#### weight size category and the 95% CI:



Estimate_Biomass_Per_Size_Category <- function(x) 
{
  df <- as.data.frame(x)
  Biomass_SmallSize_Herbivores_Mean <- sum(subset(df, SC_1=="S")$BM * subset(df, SC_1=="S")$Mean)
  Biomass_SmallSize_Herbivores_Min <- sum(subset(df, SC_1=="S")$BM * subset(df, SC_1=="S")$Min)
  Biomass_SmallSize_Herbivores_Max <- sum(subset(df, SC_1=="S")$BM * subset(df, SC_1=="S")$Max)
  Biomass_MediumSize_Herbivores_Mean <- sum(subset(df, SC_1=="M")$BM * subset(df, SC_1=="M")$Mean)
  Biomass_MediumSize_Herbivores_Min <- sum(subset(df, SC_1=="M")$BM * subset(df, SC_1=="M")$Min)
  Biomass_MediumSize_Herbivores_Max <- sum(subset(df, SC_1=="M")$BM * subset(df, SC_1=="M")$Max)
  Biomass_Large_Herbivores_Mean <- sum(subset(df, SC_1=="L")$BM * subset(df, SC_1=="L")$Mean)
  Biomass_Large_Herbivores_Min <- sum(subset(df, SC_1=="L")$BM * subset(df, SC_1=="L")$Min)
  Biomass_Large_Herbivores_Max <- sum(subset(df, SC_1=="L")$BM * subset(df, SC_1=="L")$Max)
  
  Herbivore_Biomass<- as.data.frame (t(rbind(Biomass_SmallSize_Herbivores_Mean, Biomass_SmallSize_Herbivores_Min, Biomass_SmallSize_Herbivores_Max,
                                             Biomass_MediumSize_Herbivores_Mean, Biomass_MediumSize_Herbivores_Min, Biomass_MediumSize_Herbivores_Max,
                                             Biomass_Large_Herbivores_Mean, Biomass_Large_Herbivores_Min, Biomass_Large_Herbivores_Max )))
  Herbivore_Biomass$Region <- Region
  
  return(Herbivore_Biomass)
}

########################################################################################################
#
# NPP CLUSTERS
#
#_____________________________________________________________

#Read file:
NPP<- readRDS(file = "NPP_Clusters.rds")

### Compute the DCORT dissimilarity index to compare the similarity of the 
### evolutionary trends in the estimated NPP during the MIS 3 

DCORT <- TSclust::diss(SERIES = t(NPP), METHOD = "CORT", k=1) 
# k= 1, so the contribution of the behavior proximity is 46% and that of the
# values 54% (Montero & Vilar, 2015)

hc <- stats::hclust(DCORT, method="complete") # Clustering from the DCORT outcomes

#Plot results:
hcPlot <- hc %>%
  color_branches(h=2) %>%
  set("branches_lwd", 2) %>%
  color_labels (h=2)%>%
  set("labels_cex", .5)

circlize_dendrogram(hcPlot,facing = "outside", labels = TRUE, 
                    dend_track_height = 0.7, labels_track_height = 0.2)  

# Explore and save outputs

hc$height
output<-  data.frame("heighta" = c(NA))
output<- hc$labels
output
Output_Cluster<- data.frame(output, cluster = cutree(hc, h = 2))
Output_Cluster

#Save outputs:
# write.csv(Output_Cluster, "Cluster.csv")


##########################################################
## Evolution of the NPP during the MIS3 in each cluster


# Read file
NPP_Dataset <-readRDS(file = "NPP_Cluster_1.rds")

# Matrix transformation, NPP without Age & colors for plot
NPP<- NPP_Dataset[2:55]
df <- data.frame(x = seq_along(NPP[, 1]),NPP)
df <- melt(df, id.vars = "x")
df$Age<- NPP_Dataset$Age 

cols <- c("gray", "gray", "gray", "gray", "gray", "gray", "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray")

MeanValue<- subset(df, variable=="Average")

Cluster_1<-ggplot(df, aes(x = Age, y = value, color= variable)) +
  geom_line( size = 0.75)+
  scale_color_manual(values = cols)+
  geom_line(data = MeanValue, aes(x = Age, y = value), color = "blue", size = 1) +
  theme_classic()+
  theme(legend.position = "none") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) 

Cluster_1

###############################################################
#  Cluster 2

# Read file
NPP_Dataset <-readRDS(file = "NPP_Cluster_2.rds")

# Matrix transformation
NPP<- NPP_Dataset[2:116]
df <- data.frame(x = seq_along(NPP[, 1]), NPP)
df <- melt(df, id.vars = "x")
df$Age<- NPP_Dataset$Age

cols <- c("gray", "gray", "gray", "gray", "gray", "gray", "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray", "gray", "gray", "gray", "gray", "gray", "gray", "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray", "gray","gray","gray")

MeanValue<- subset(df, variable=="Average")

Cluster_2<-ggplot(df, aes(x = Age, y = value, color= variable)) +
  geom_line( size = 0.75)+
  scale_color_manual(values = cols)+
  geom_line(data = MeanValue, aes(x = Age, y = value), color = "deepskyblue1", size = 1) +
  theme_classic()+
  theme(legend.position = "none") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) 

Cluster_2


###############################################################
#  Cluster 3

# Read file
NPP_Dataset <-readRDS(file = "NPP_Cluster_3.rds")

# Matrix transformation
NPP<- NPP_Dataset[2:39]
df <- data.frame(x = seq_along(NPP[, 1]), NPP)
df <- melt(df, id.vars = "x")
df$Age<- NPP_Dataset$Age

cols <- c("gray", "gray", "gray", "gray", "gray", "gray", "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray")

MeanValue<- subset(df, variable=="Average")

Cluster_3<-ggplot(df, aes(x = Age, y = value, color= variable)) +
  geom_line( size = 0.75)+
  scale_color_manual(values = cols)+
  geom_line(data = MeanValue, aes(x = Age, y = value), color = "green", size = 1) +
  theme_classic()+
  theme(legend.position = "none") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) 

Cluster_3

###############################################################
#  Cluster 4

# Read file:
NPP_Dataset <-readRDS(file = "NPP_Cluster_4.rds")

# Matrix transformation
NPP<- NPP_Dataset[2:71]
df <- data.frame(x = seq_along(NPP[, 1]), NPP)
df <- melt(df, id.vars = "x")
df$Age<- NPP_Dataset$Age

cols <- c("gray", "gray", "gray", "gray", "gray", "gray", "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray", "gray", "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray")

MeanValue<- subset(df, variable=="Average")

Cluster_4<-ggplot(df, aes(x = Age, y = value, color= variable)) +
  geom_line( size = 0.75)+
  scale_color_manual(values = cols)+
  geom_line(data = MeanValue, aes(x = Age, y = value), color = "deeppink2", size = 1) +
  theme_classic()+
  theme(legend.position = "none") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) 

Cluster_4

###############################################################
#  Cluster 5

# Matrix transformation:

NPP_Dataset <-readRDS(file = "NPP_Cluster_5.rds")

# NPP without Age
NPP<- NPP_Dataset[2:8]
df <- data.frame(x = seq_along(NPP[, 1]), NPP)
df <- melt(df, id.vars = "x")
df$Age<- NPP_Dataset$Age

cols <- c("gray", "gray", "gray", "gray", "gray", "gray", "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray", "gray", "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray")

MeanValue<- subset(df, variable=="Average")

Cluster_5<-ggplot(df, aes(x = Age, y = value, color= variable)) +
  geom_line( size = 0.75)+
  scale_color_manual(values = cols)+
  geom_line(data = MeanValue, aes(x = Age, y = value), color = "red", size = 1) +
  theme_classic()+
  theme(legend.position = "none") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) 

Cluster_5
###############################################################
#  Cluster 6

# Read file
NPP_Dataset <-readRDS(file = "NPP_Cluster_6.rds")

# Matrix transformation
NPP<- NPP_Dataset[2:8]
df <- data.frame(x = seq_along(NPP[, 1]), NPP)
df <- melt(df, id.vars = "x")
df$Age<- NPP_Dataset$Age


cols <- c("gray", "gray", "gray", "gray", "gray", "gray", "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray", "gray", "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray",
          "gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray","gray")

MeanValue<- subset(df, variable=="Average")

Cluster_6<-ggplot(df, aes(x = Age, y = value, color= variable)) +
  geom_line( size = 0.75)+
  scale_color_manual(values = cols)+
  geom_line(data = MeanValue, aes(x = Age, y = value), color = "brown", size = 1) +
  theme_classic()+
  theme(legend.position = "none") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) 

Cluster_6


grid.arrange(Cluster_1, Cluster_2, Cluster_3, Cluster_4, Cluster_5, Cluster_6)


#_________________________________________________________________________________
#
## CLUSTER CLASSIFICATION OF THE HERBIVORE PALEOCOMMUNITIES (PCOM)  
#
#_______________________________________________


### PCOMs comparison according to Jaccard Similarity Index (JSI) herbivores

Fauna <-readRDS(file = "Jaccard_Index.rds")
Fauna[,2:30]

### Compute the JSI
JSI<-vegdist(Fauna[,2:30] ,method="jaccard", na.rm = TRUE)
hc <- hclust(JSI)  

# Plot
labs = Fauna[,1] #new labels
rownames(Fauna)<-labs
JSI<-vegdist(Fauna[,2:30] ,method="jaccard", na.rm = TRUE)
hc <- hclust(JSI)  

plot(as.dendrogram(hc),horiz=T)


##______________________
###
#### RAREFACTION ANALYSIS
###
##
#_____________________

#HERBIVORES

R_1 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                 colNames=TRUE, sheet="R_1")
R_2 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                 colNames=TRUE, sheet="R_2") 
R_3 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                 colNames=TRUE, sheet="R_3")
R_4 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                 colNames=TRUE, sheet="R_4") 
R_5 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                 colNames=TRUE, sheet="R_5") 
R_6 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                 colNames=TRUE, sheet="R_6")
R_7 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                 colNames=TRUE, sheet="R_7")
R_8 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                 colNames=TRUE, sheet="R_8")
R_9 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                 colNames=TRUE, sheet="R_9")
R_10 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                  colNames=TRUE, sheet="R_10")
R_11 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                  colNames=TRUE, sheet="R_11") 
R_12 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                          colNames=TRUE, sheet="R_12")
R_13 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                                colNames=TRUE, sheet="R_13")
R_14 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                               colNames=TRUE, sheet="R_14")
R_15 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                                 colNames=TRUE, sheet="R_15")
R_16 <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                          colNames=TRUE, sheet="R_16") 

# make a matrix as type "integer"

R_1_p <- as.matrix(apply(R_1[,-1],2,as.integer))
row.names(R_1_p) <- R_1$Species 
R_2_p <- as.matrix(apply(R_2[,-1],2,as.integer))
row.names(R_2_p) <- R_2$Species 
R_3_p <- as.matrix(apply(R_3[,-1],2,as.integer))
row.names(R_3_p) <- R_3$Species 
R_4_p<-as.matrix(apply(R_4[,-1],2,as.integer))
row.names(R_4_p) <- R_4$Species 
R_5_p <- as.matrix(apply(R_5[,-1],2,as.integer))
row.names(R_5_p ) <- R_5$Species 
R_6_p <- as.matrix(apply(R_6[,-1],2,as.integer))
row.names(R_6_p) <- R_6$Species 
R_7_p <- as.matrix(apply(R_7[,-1],2,as.integer))
row.names(R_7_p) <- R_7$Species 
R_8_p <- as.matrix(apply(R_8[,-1],2,as.integer))
row.names(R_8_p) <- R_8$Species 
R_9_p <- as.matrix(apply(R_9[,-1],2,as.integer))
row.names(R_9_p) <- R_9$Species 
R_10_p <- as.matrix(apply(R_10[,-1],2,as.integer))
row.names(R_10_p) <- R_10$Species 
R_11_p <- as.matrix(apply(R_11[,-1],2,as.integer))
row.names(R_11_p) <- R_11$Species 
R_12_p <- as.matrix(apply(R_12[,-1],2,as.integer))
row.names(R_12_p) <- R_12$Species 
R_13_p <- as.matrix(apply(R_13[,-1],2,as.integer))
row.names(R_13_p) <- R_13$Species 
R_14_p <- as.matrix(apply(R_14[,-1],2,as.integer))
row.names(R_14_p) <- R_14$Species 
R_15_p <- as.matrix(apply(R_15[,-1],2,as.integer))
row.names(R_15_p) <- R_15$Species
R_16_p <- as.matrix(apply(R_16[,-1],2,as.integer))
row.names(R_16_p) <- R_16$Species 


SpeciesDataset = list(a_R1=R_1_p, b_R2=R_2_p, c_R3=R_3_p, d_R4 =R_4_p,e_R5=R_5_p,
                      f_R6=R_6_p,g_R7=R_7_p,h_R8=R_8_p,i_R9=R_9_p, j_R10=R_10_p,
                      k_R11 = R_11_p, l_R12= R_12_p,m_R13=R_13_p, n_R14=R_14_p,
                      o_R15=R_15_p, p_R16=R_16_p)


## Species richness and extrapolation.

out.raw <- iNEXT(SpeciesDataset, datatype="incidence_raw", endpoint=500, nboot=100)

#PLOT

p1<- ggiNEXT(out.raw, facet.var="Assemblage") 


p1 + facet_wrap(~Assemblage, ncol=4)

# save outputs

# Outputs_a<- as.data.frame(out.raw$AsyEst)
# Outputs_b <- as.data.frame (out.raw$iNextEs)

# write.xlsx(Outputs_a, "Rarefaction_Outputs_Richness_Herbivores.xlsx")
# write.xlsx(Outputs_b, "Rarefaction_Outputs_Extrapolation_Herbivores.xlsx")



#_________________________________________________________________________________________________________
#
#
#
####### COMPUTE THE HERBIVORE ABUNDANCE IN EACH REGION DURING MIS 3 (55-30 KY BP)
#
#
#
#_________________________________________________________________________________________________________




#_________________________________________________________________________________
#
############################################ REGION 1 (R1)  ############################################
#
#_________________________________________________________________________________

NPP.R1 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                              colNames=TRUE, sheet="NPP.R1")
# Stadial-Interstadial durations:
SI <- read.xlsx("GIChron.xlsx", rowNames=FALSE,
                colNames=TRUE, sheet="GIChron")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R1, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R1<-Summary_NPP 

# Save outputs:
# write.csv(Summary_NPP, "NPP_Mesotemperate.csv")

### Dataset with chronological outputs obtained from Bayesian age models with
### the filtering criteria (FC) 1 and 2 (see main text for details). To be
### incorporated into the NPP plots:

Chrono_df <-readRDS(file = "Chrono.rds")

Dataset_R_1_FC_1_M<- filter(Chrono_df,   Code == "R_1_FC1" & Culture == "End Mousterian" ) 
Dataset_R_1_FC_2_M<- filter(Chrono_df,   Code == "R_1_FC2" & Culture == "End Mousterian" )
Dataset_R_1_FC_1_EUP<- filter(Chrono_df,   Code == "R_1_FC1" & Culture == "Start EUP" )
Dataset_R_1_FC_2_EUP<- filter(Chrono_df,   Code == "R_1_FC2" & Culture == "Start EUP" )

### Plot the temporal evolution of the NPP in the Danube region: 

R1_NPP_Plot <- ggplot(NPP.R1, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                 ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.53),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_1") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
geom_rect(data = Dataset_R_1_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
          inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_1_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  
  geom_rect(data = Dataset_R_1_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_1_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  
  geom_rect(data = Dataset_R_1_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_1_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  
  geom_rect(data = Dataset_R_1_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_1_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R1_NPP_Plot
 




#__________________

## HERBIVORE ABUNDANCE PER STAIDAL/INTERSTADIAL:

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R1")

### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the Danube region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "Danube"
Density_R1<- Estimate_Population_Density("Danube")
Biomass_R1<- Estimate_Biomass_Per_Size_Category(Density_R1)
Density_R1 # see outcomes
Biomass_R1 # see outcomes

#_________________________________________________________________________________
#
############################################ REGION 2 (R_2)  ############################################
#
#_________________________________________________________________________________

NPP.R2 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                            colNames=TRUE, sheet="NPP.R2")


Summary_NPP <- aggregate(NPP~Region,data=NPP.R2, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R2<-Summary_NPP 

# Save outputs:
# write.csv(Summary_NPP, "NPP_Mesotemperate.csv")
Dataset_R_2_FC_1_M<- filter(Chrono_df,   Code == "R_2_FC1" & Culture == "End Mousterian" )
Dataset_R_2_FC_2_M<- filter(Chrono_df,   Code == "R_2_FC2" & Culture == "End Mousterian" )
Dataset_R_2_FC_1_EUP<- filter(Chrono_df,   Code == "R_2_FC1" & Culture == "Start EUP" )
Dataset_R_2_FC_2_EUP<- filter(Chrono_df,   Code == "R_2_FC2" & Culture == "Start EUP" )

### Plot the temporal evolution of the NPP in the R_2 region: 

R2_NPP_Plot <- ggplot(NPP.R2, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                  ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.5),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_2") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  geom_rect(data = Dataset_R_2_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_2_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_2_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_2_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_2_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_2_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_2_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_2_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")
	
	


R2_NPP_Plot


#__________________

## HERBIVORE ABUNDANCE PER STAIDAL/INTERSTADIAL:

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R2")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the R_2 region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "Carpathian"
Density_R2<- Estimate_Population_Density("Carpathian")
Biomass_R2<- Estimate_Biomass_Per_Size_Category(Density_R2)
Density_R2
Biomass_R2


#_________________________________________________________________________________
#
############################################ REGION 3 (R_3)  ############################################
#
#_________________________________________________________________________________

NPP.R3 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                        colNames=TRUE, sheet="NPP.R3")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R3, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R3<-Summary_NPP 

# Save outputs:
# write.csv(Summary_NPP, "NPP_Mesotemperate.csv")
Dataset_R_3_FC_1_M<- filter(Chrono_df,   Code == "R_3_FC1" & Culture == "End Mousterian" )
Dataset_R_3_FC_2_M<- filter(Chrono_df,   Code == "R_3_FC2" & Culture == "End Mousterian" )
Dataset_R_3_FC_1_EUP<- filter(Chrono_df,   Code == "R_3_FC1" & Culture == "Start EUP" )
Dataset_R_3_FC_2_EUP<- filter(Chrono_df,   Code == "R_3_FC2" & Culture == "Start EUP" )
### Plot the temporal evolution of the NPP in the Ionian region: 

R3_NPP_Plot <- ggplot(NPP.R3, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                          ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.5),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_3") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  geom_rect(data = Dataset_R_3_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_3_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_3_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_3_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_3_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_3_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_3_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_3_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R3_NPP_Plot


#__________________

## HERBIVORE ABUNDANCE PER STAIDAL/INTERSTADIAL:

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R3")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the Ionian region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC) 

Region <- "Ionian"
Density_R3<- Estimate_Population_Density("Ionian")
Biomass_R3<- Estimate_Biomass_Per_Size_Category(Density_R3)
Density_R3
Biomass_R3

#_________________________________________________________________________________
#
############################################ REGION 4 (R4)  ############################################
#
#_________________________________________________________________________________

NPP.R4 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                                         colNames=TRUE, sheet="NPP.R4")


Summary_NPP <- aggregate(NPP~Region,data=NPP.R4, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R4<-Summary_NPP 

# Save outputs:
# write.csv(Summary_NPP, "NPP_Mesotemperate.csv")
Dataset_R_4_FC_1_M<- filter(Chrono_df,   Code == "R_4_FC1" & Culture == "End Mousterian" )

Dataset_R_4_FC_2_M<- filter(Chrono_df,   Code == "R_4_FC2" & Culture == "End Mousterian" )
Dataset_R_4_FC_1_EUP<- filter(Chrono_df,   Code == "R_4_FC1" & Culture == "Start EUP" )
Dataset_R_4_FC_2_EUP<- filter(Chrono_df,   Code == "R_4_FC2" & Culture == "Start EUP" )

### Plot the temporal evolution of the NPP in the Danube region: 

R4_NPP_Plot <- ggplot(NPP.R4, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                                            ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.5),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_4") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  geom_rect(data = Dataset_R_4_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_4_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_4_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_4_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_4_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_4_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_4_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_4_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R4_NPP_Plot


#__________________

## HERBIVORE ABUNDANCE

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R4")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the R_4 region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "EurosiberianUpperDanube"
Density_R4<- Estimate_Population_Density("EurosiberianUpperDanube")
Biomass_R4<- Estimate_Biomass_Per_Size_Category(Density_R4)
Density_R4
Biomass_R4



#_________________________________________________________________________________
#
############################################ REGION 5 (R_5)  ############################################
#
#_________________________________________________________________________________

NPP.R5 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                                    colNames=TRUE, sheet="NPP.R5")


Summary_NPP <- aggregate(NPP~Region,data=NPP.R5, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R5<-Summary_NPP 

# Save outputs:
# write.csv(Summary_NPP, "NPP_Mesotemperate.csv")
Dataset_R_5_FC_1_M<- filter(Chrono_df,   Code == "R_5_FC1" & Culture == "End Mousterian" )
Dataset_R_5_FC_2_M<- filter(Chrono_df,   Code == "R_5_FC2" & Culture == "End Mousterian" )
Dataset_R_5_FC_1_EUP<- filter(Chrono_df,   Code == "R_5_FC1" & Culture == "Start EUP" )
Dataset_R_5_FC_2_EUP<- filter(Chrono_df,   Code == "R_5_FC2" & Culture == "Start EUP" )

### Plot the temporal evolution of the NPP in the R_2 region: 

R5_NPP_Plot <- ggplot(NPP.R5, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                                  ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.5),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_5") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  geom_rect(data = Dataset_R_5_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_5_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_5_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_5_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_5_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_5_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_5_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_5_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R5_NPP_Plot

#__________________

## HERBIVORE ABUNDANCE

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R5")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the CentralNorthEurope region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC) 

Region <- "CentralNorthEurope"
Density_R5<- Estimate_Population_Density("CentralNorthEurope")
Biomass_R5<- Estimate_Biomass_Per_Size_Category(Density_R5)
Density_R5
Biomass_R5

#_________________________________________________________________________________
#
############################################ REGION 6 (R_6)  ############################################
#
#_________________________________________________________________________________

NPP.R6 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                          colNames=TRUE, sheet="NPP.R6")


Summary_NPP <- aggregate(NPP~Region,data=NPP.R6, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R6<-Summary_NPP 

Dataset_R_6_FC_1_M<- filter(Chrono_df,   Code == "R_6_FC1" & Culture == "End Mousterian" )
Dataset_R_6_FC_2_M<- filter(Chrono_df,   Code == "R_6_FC2" & Culture == "End Mousterian" )
Dataset_R_6_FC_1_EUP<- filter(Chrono_df,   Code == "R_6_FC1" & Culture == "Start EUP" )
Dataset_R_6_FC_2_EUP<- filter(Chrono_df,   Code == "R_6_FC2" & Culture == "Start EUP" )

### Plot the temporal evolution of the NPP in the R_6 region: 

R_6_NPP_Plot <- ggplot(NPP.R6, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                              ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.5),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_6") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
 
  geom_rect(data = Dataset_R_6_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_6_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_6_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_6_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_6_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_6_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_6_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_6_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R_6_NPP_Plot



#__________________

## HERBIVORE ABUNDANCE PER STAIDAL/INTERSTADIAL:

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R6")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the R_6 region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "Adriatic"
Density_R6<- Estimate_Population_Density("Adriatic")
Biomass_R6<- Estimate_Biomass_Per_Size_Category(Density_R6)
Density_R6
Biomass_R6


#_________________________________________________________________________________
#
############################################  REGION 7  ############################################
#
#_________________________________________________________________________________

NPP.R7 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                           colNames=TRUE, sheet="NPP.R7")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R7, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R7<-Summary_NPP 


# Save outputs:
# write.csv(Summary_NPP, "NPP_R_7.csv")

Dataset_R_7_FC_1_M<- filter(Chrono_df,   Code == "R_7_FC1" & Culture == "End Mousterian" )
Dataset_R_7_FC_2_M<- filter(Chrono_df,   Code == "R_7_FC2" & Culture == "End Mousterian" )
Dataset_R_7_FC_1_EUP<- filter(Chrono_df,   Code == "R_7_FC1" & Culture == "Start EUP" )
Dataset_R_7_FC_2_EUP<- filter(Chrono_df,   Code == "R_7_FC2" & Culture == "Start EUP" )

### Plot the temporal evolution of the NPP in the R_7 region: 

R_7_NPP_Plot <- ggplot(NPP.R7, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.5),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  geom_line( color="black", size = 1) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_7") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  
  geom_rect(data = Dataset_R_7_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_7_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_7_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_7_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_7_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_7_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_7_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_7_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R_7_NPP_Plot




#__________________

## HERBIVORE ABUNDANCE PER STAIDAL/INTERSTADIAL:

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R7")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the R_7 region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "Prealpine"
Density_R7<- Estimate_Population_Density("Prealpine")
Biomass_R7<- Estimate_Biomass_Per_Size_Category(Density_R7)


#_________________________________________________________________________________
#
############################################ REGION 8 (R_8)  ############################################
#
#_________________________________________________________________________________

NPP.R8 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                            colNames=TRUE, sheet="NPP.R8")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R8, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R8<-Summary_NPP 

Dataset_R_8_FC_1_M<- filter(Chrono_df,   Code == "R_8_FC1" & Culture == "End Mousterian" )
Dataset_R_8_FC_2_M<- filter(Chrono_df,   Code == "R_8_FC2" & Culture == "End Mousterian" )
Dataset_R_8_FC_1_EUP<- filter(Chrono_df,   Code == "R_8_FC1" & Culture == "Start EUP" )
Dataset_R_8_FC_2_EUP<- filter(Chrono_df,   Code == "R_8_FC2" & Culture == "Start EUP" )



### Plot the temporal evolution of the NPP in the R_8 region: 

R_8_NPP_Plot <- ggplot(NPP.R8, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                  ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.5),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_8") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  
  geom_rect(data = Dataset_R_8_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_8_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_8_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_8_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_8_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_8_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_8_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_8_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R_8_NPP_Plot


#__________________

## HERBIVORE ABUNDANCE PER STAIDAL/INTERSTADIAL:

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R8")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the R_8 region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "Tyrrhenian"
Density_R8<- Estimate_Population_Density("Tyrrhenian")
Biomass_R8<- Estimate_Biomass_Per_Size_Category(Density_R8)
Density_R8
Biomass_R8

#_________________________________________________________________________________
#
############################################ REGION 9 (R_9)  ############################################
#
#_________________________________________________________________________________

NPP.R9 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                          colNames=TRUE, sheet="NPP.R9")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R9, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R9<-Summary_NPP 

Dataset_R_9_FC_1_M<- filter(Chrono_df,   Code == "R_9_FC1" & Culture == "End Mousterian" )
Dataset_R_9_FC_2_M<- filter(Chrono_df,   Code == "R_9_FC2" & Culture == "End Mousterian" )
Dataset_R_9_FC_1_EUP<- filter(Chrono_df,   Code == "R_9_FC1" & Culture == "Start EUP" )
Dataset_R_9_FC_2_EUP<- filter(Chrono_df,   Code == "R_9_FC2" & Culture == "Start EUP" )

### Plot the temporal evolution of the NPP in the R_9 region: 

R_9_NPP_Plot <- ggplot(NPP.R9, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                              ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.52),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_9") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  
  geom_rect(data = Dataset_R_9_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_9_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_9_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_9_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_9_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_9_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_9_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_9_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R_9_NPP_Plot



#__________________

## HERBIVORE ABUNDANCE PER STAIDAL/INTERSTADIAL:

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R9")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the R_9 region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "Ligurian"
Density_R9<- Estimate_Population_Density("Ligurian")
Biomass_R9<- Estimate_Biomass_Per_Size_Category(Density_R9)
Density_R9
Biomass_R9


#_________________________________________________________________________________
#
############################################ REGION 10  ############################################
#
#_________________________________________________________________________________

NPP.R10 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                             colNames=TRUE, sheet="NPP.R10")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R10, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R10<-Summary_NPP 

# Save outputs:
# write.csv(Summary_NPP, "NPP_Mesotemperate.csv")
Dataset_R_10_FC_1_M<- filter(Chrono_df,   Code == "R_10_FC1" & Culture == "End Mousterian" )
Dataset_R_10_FC_2_M<- filter(Chrono_df,   Code == "R_10_FC2" & Culture == "End Mousterian" )
Dataset_R_10_FC_1_EUP<- filter(Chrono_df,   Code == "R_10_FC1" & Culture == "Start EUP" )
Dataset_R_10_FC_2_EUP<- filter(Chrono_df,   Code == "R_10_FC2" & Culture == "Start EUP" )

### Plot the temporal evolution of the NPP in the Ionian region: 

R10_NPP_Plot <- ggplot(NPP.R10, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                    ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.5),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_10") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  
  
  geom_rect(data = Dataset_R_10_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_10_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_10_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_10_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_10_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_10_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_10_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_10_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R10_NPP_Plot

#__________________

## HERBIVORE ABUNDANCE

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R10")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the MeditFrance region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "MeditFrance"
Density_R10<- Estimate_Population_Density("MeditFrance")
Biomass_R10<- Estimate_Biomass_Per_Size_Category(Density_R10)
Density_R10
Biomass_R10

#_________________________________________________________________________________
#
############################################ REGION 11 (R_11)  ############################################
#
#_________________________________________________________________________________

NPP.R11 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                          colNames=TRUE, sheet="NPP.R11")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R11, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R11<-Summary_NPP 

# Save outputs:
# write.csv(Summary_NPP, "NPP_Mesotemperate.csv")
Dataset_R_11_FC_1_M<- filter(Chrono_df,   Code == "R_11_FC1" & Culture == "End Mousterian" )
Dataset_R_11_FC_2_M<- filter(Chrono_df,   Code == "R_11_FC2" & Culture == "End Mousterian" )
Dataset_R_11_FC_1_EUP<- filter(Chrono_df,   Code == "R_11_FC1" & Culture == "Start EUP" )
Dataset_R_11_FC_2_EUP<- filter(Chrono_df,   Code == "R_11_FC2" & Culture == "Start EUP" )

### Plot the temporal evolution of the NPP in the Cantabrian region: 

R_11_NPP_Plot <- ggplot(NPP.R11, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                              ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.56),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_11") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  geom_rect(data = Dataset_R_11_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_11_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_11_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_11_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_11_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_11_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_11_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_11_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R_11_NPP_Plot


#__________________

## HERBIVORE ABUNDANCE

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R11")

### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the R_11 region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "Aquitane"
Density_R11<- Estimate_Population_Density("Aquitane")
Biomass_R11<- Estimate_Biomass_Per_Size_Category(Density_R11)
Density_R11
Biomass_R11



#_________________________________________________________________________________
#
############################################ REGION 12 (R_12)  ############################################
#
#_________________________________________________________________________________

NPP.R12 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                            colNames=TRUE, sheet="NPP.R12")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R12, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R12<-Summary_NPP 

# Save outputs:
# write.csv(Summary_NPP, "NPP_Mesotemperate.csv")
Dataset_R_12_FC_1_M<- filter(Chrono_df,   Code == "R_12_FC1" & Culture == "End Mousterian" )
Dataset_R_12_FC_2_M<- filter(Chrono_df,   Code == "R_12_FC2" & Culture == "End Mousterian" )
Dataset_R_12_FC_1_EUP<- filter(Chrono_df,   Code == "R_12_FC1" & Culture == "Start EUP" )
Dataset_R_12_FC_2_EUP<- filter(Chrono_df,   Code == "R_12_FC2" & Culture == "Start EUP" )

### Plot the temporal evolution of the NPP in the Cantabrian region: 

R12_NPP_Plot <- ggplot(NPP.R12, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                  ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.54),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_12") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
 
  geom_rect(data = Dataset_R_12_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_12_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_12_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_12_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_12_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_12_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_12_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_12_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R12_NPP_Plot



#__________________

## HERBIVORE ABUNDANCE PER STAIDAL/INTERSTADIAL:

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R12")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the Cantabrian region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "Cantabrian"
Density_R12<- Estimate_Population_Density("Cantabrian")
Biomass_R12<- Estimate_Biomass_Per_Size_Category(Density_R12)
Density_R12
Biomass_R12

#_________________________________________________________________________________
#
############################################ REGION 13  ############################################
#
#_________________________________________________________________________________

NPP.R13 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                                    colNames=TRUE, sheet="NPP.R13")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R13, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R13<-Summary_NPP 

Dataset_R_13_FC_1_M<- filter(Chrono_df,   Code == "R_13_FC1" & Culture == "End Mousterian" )
Dataset_R_13_FC_2_M<- filter(Chrono_df,   Code == "R_13_FC2" & Culture == "End Mousterian" )
Dataset_R_13_FC_1_EUP<- filter(Chrono_df,   Code == "R_13_FC1" & Culture == "Start EUP" )
Dataset_R_13_FC_2_EUP<- filter(Chrono_df,   Code == "R_13_FC2" & Culture == "Start EUP" )


### Plot the temporal evolution of the NPP in the R_13 region: 

R_13_NPP_Plot <- ggplot(NPP.R13, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                                  ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.5),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_13") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  geom_rect(data = Dataset_R_13_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_13_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_13_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_13_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_13_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_13_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_13_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_13_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R_13_NPP_Plot



#__________________

## HERBIVORE ABUNDANCE PER STAIDAL/INTERSTADIAL:

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R13")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the R_13 region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "Supramediterranean"
Density_R13<- Estimate_Population_Density("Supramediterranean")
Biomass_R13<- Estimate_Biomass_Per_Size_Category(Density_R13)
Density_R13
Biomass_R13


#_________________________________________________________________________________
#
############################################ REGION 14  ############################################
#
#_________________________________________________________________________________

NPP.R14 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                                   colNames=TRUE, sheet="NPP.R14")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R14, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R14<-Summary_NPP 

Dataset_R_14_FC_1_M<- filter(Chrono_df,   Code == "R_14_FC1" & Culture == "End Mousterian" )
Dataset_R_14_FC_2_M<- filter(Chrono_df,   Code == "R_14_FC2" & Culture == "End Mousterian" )
Dataset_R_14_FC_1_EUP<- filter(Chrono_df,   Code == "R_14_FC1" & Culture == "Start EUP" )
Dataset_R_14_FC_2_EUP<- filter(Chrono_df,   Code == "R_14_FC2" & Culture == "Start EUP" )


### Plot the temporal evolution of the NPP in the R_14 region: 

R_14_NPP_Plot <- ggplot(NPP.R14, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                                ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.53),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_14") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +

  geom_rect(data = Dataset_R_14_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_14_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_14_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_14_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_14_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_14_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_14_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_14_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R_14_NPP_Plot


#__________________

## HERBIVORE ABUNDANCE PER STAIDAL/INTERSTADIAL:

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R14")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the R_14 region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "Mesomediterranean"
Density_R14<- Estimate_Population_Density("Mesomediterranean")
Biomass_R14<- Estimate_Biomass_Per_Size_Category(Density_R14)
Density_R14
Biomass_R14

#_________________________________________________________________________________
#
############################################ REGION 15 ############################################
#
#_________________________________________________________________________________

NPP.R15 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                                     colNames=TRUE, sheet="NPP.R15")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R15, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R15<-Summary_NPP 

Dataset_R_15_FC_1_M<- filter(Chrono_df,   Code == "R_15_FC1" & Culture == "End Mousterian" )
Dataset_R_15_FC_2_M<- filter(Chrono_df,   Code == "R_15_FC2" & Culture == "End Mousterian" )
Dataset_R_15_FC_1_EUP<- filter(Chrono_df,   Code == "R_15_FC1" & Culture == "Start EUP" )
Dataset_R_15_FC_2_EUP<- filter(Chrono_df,   Code == "R_15_FC2" & Culture == "Start EUP" )

### Plot the temporal evolution of the NPP in the R_15 region: 

R_15_NPP_Plot <- ggplot(NPP.R15, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                                    ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.5),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_15") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  geom_rect(data = Dataset_R_15_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_15_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_15_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_15_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_15_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_15_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_15_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_15_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R_15_NPP_Plot

#__________________

## HERBIVORE ABUNDANCE

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R15")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the R_15 region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC)

Region <- "Thermomediterranean"
Density_R15<- Estimate_Population_Density("Thermomediterranean")
Biomass_R15<- Estimate_Biomass_Per_Size_Category(Density_R15)
Density_R15
Biomass_R15


#_________________________________________________________________________________
#
############################################ REGION 16  ############################################
#
#_________________________________________________________________________________

NPP.R16 <- read.xlsx("NPP_Regions.xlsx", rowNames=FALSE,
                             colNames=TRUE, sheet="NPP.R16")

Summary_NPP <- aggregate(NPP~Region,data=NPP.R16, function(x) c(mean=mean(x), sd = sd(x), cv=co.var(x)))
Summary_NPP
NPP_R16<-Summary_NPP 

# Save outputs:
# write.csv(Summary_NPP, "NPP_Mesotemperate.csv")
Dataset_R_16_FC_1_M<- filter(Chrono_df,   Code == "R_16_FC1" & Culture == "End Mousterian" )
Dataset_R_16_FC_2_M<- filter(Chrono_df,   Code == "R_16_FC2" & Culture == "End Mousterian" )
Dataset_R_16_FC_1_EUP<- filter(Chrono_df,   Code == "R_16_FC1" & Culture == "Start EUP" )
Dataset_R_16_FC_2_EUP<- filter(Chrono_df,   Code == "R_16_FC2" & Culture == "Start EUP" )


### Plot the temporal evolution of the NPP in the Ionian region: 

R_16_NPP_Plot <- ggplot(NPP.R16, aes(x = Age, y = NPP, ymin= NPP - (2*sd),
                                                    ymax= NPP + (2 * sd))) +
  geom_rect(data = SI, aes(xmin = B , xmax = E, ymin = -Inf, ymax = 0.5),
            inherit.aes=FALSE, alpha = 0.1, fill = c("orange")) +
  scale_x_reverse(breaks = seq(30000, 50000, 5000)) +
  geom_ribbon(fill="grey70") +
  geom_line( color="black", size = 1) +
  ggtitle ("R_16") +
  xlab ("age BP")+
  ylab (expression('NPP (kg/m'^2/"yr)")) +
  ylim(0, 0.71) +
  geom_rect(data = Dataset_R_16_FC_1_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_16_FC_1_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_16_FC_2_M, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_16_FC_2_M, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("darkorchid")) +
  geom_rect(data = Dataset_R_16_FC_1_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.648, ymax = 0.661),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_16_FC_1_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.644, ymax = 0.665),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_16_FC_2_EUP, aes(xmin = `95_LL_M` , xmax = `95_UL_M`, ymin = 0.688, ymax = 0.701),
            inherit.aes=FALSE, alpha = 0.5, fill = c("chartreuse3")) +
  geom_rect(data = Dataset_R_16_FC_2_EUP, aes(xmin = `68_LL_M` , xmax = `68_UL_M`, ymin = 0.684, ymax = 0.705),
            inherit.aes=FALSE, alpha = 1, fill = c("chartreuse3")) +
  theme_classic(base_size = 14, base_family = "serif")+ 
  theme(legend.position = "none")

R_16_NPP_Plot

#__________________

## HERBIVORE ABUNDANCE

#__________________


###### Primary consumer species and their body masses (BM)

Fauna <- read.xlsx("MIS3_Fauna_Dataset.xlsx", rowNames=FALSE,
                   colNames=TRUE, sheet="Fauna.R16")


### Abundance of herbivore species recovered from the archeo-paleontological assemblages covering
### the period comprised between the GI13 and the GI9 in the Fauna.R_16 region:

Fauna_BodyMass <- na.omit (Fauna$BM)
Species_List <- na.omit (Fauna$Species)
SizeCategory <- na.omit(Fauna$SC) 

Region <- "NorthwestEurope"
Density_R16<- Estimate_Population_Density("NorthwestEurope")
Biomass_R16<- Estimate_Biomass_Per_Size_Category(Density_R16)
Density_R16
Biomass_R16



### Plot the NPP of all regions during the MIS 3

grid.arrange(R1_NPP_Plot, R2_NPP_Plot, R3_NPP_Plot, 
             R4_NPP_Plot, R5_NPP_Plot,
             R_6_NPP_Plot, R_7_NPP_Plot,R_8_NPP_Plot,
             R_9_NPP_Plot, R10_NPP_Plot,
             R_11_NPP_Plot,  R12_NPP_Plot,
             R_13_NPP_Plot, R_14_NPP_Plot, R_15_NPP_Plot,
             R_16_NPP_Plot)


# MERGE AND SAVE DATASETS

Biomass_MIS3<- rbind(Biomass_R1, Biomass_R2, Biomass_R3, Biomass_R7,
                     Biomass_R9, Biomass_R6, Biomass_R8, Biomass_R12,
                     Biomass_R13, Biomass_R14, Biomass_R15, Biomass_R4, 
                     Biomass_R5, Biomass_R10, Biomass_R16, Biomass_R11)

NPP_MIS3<- rbind(NPP_R1, NPP_R2, NPP_R3, NPP_R7,
                 NPP_R9, NPP_R6, NPP_R8, NPP_R12,
                 NPP_R13, NPP_R14, NPP_R15, NPP_R4, 
                 NPP_R5, NPP_R10, NPP_R16, NPP_R11)

Density_MIS3<- rbind(Density_R1, Density_R2, Density_R3, Density_R7,
                     Density_R9, Density_R6, Density_R8, Density_R12,
                     Density_R13, Density_R14, Density_R15,
                     Density_R4, Density_R5, Density_R10, 
                     Density_R16, Density_R11)

# Save outputs:
write.csv(Density_MIS3, "Density_MIS3.csv")
write.csv(Biomass_MIS3, "Biomass_MIS3.csv")
write.csv(NPP_MIS3, "NPP_MIS3.csv")

####_________________________________________________________
#
#### BARPLOT OF THE ESTIMATED HERBIVORE BIOMASS IN EACH REGION


#Create a new dataframe:

Small <- data.frame(Biomass = c(Biomass_MIS3[,"Biomass_SmallSize_Herbivores_Mean"]),
                    Region = (Biomass_MIS3[,"Region"]),
                    Min= (Biomass_MIS3[,"Biomass_SmallSize_Herbivores_Min"]),
                    Max= (Biomass_MIS3[,"Biomass_SmallSize_Herbivores_Max"]),
                    Size= "Small")
Medium <- data.frame(Biomass = c(Biomass_MIS3[,"Biomass_MediumSize_Herbivores_Mean"]),
                     Region = (Biomass_MIS3[,"Region"]),
                     Min= (Biomass_MIS3[,"Biomass_MediumSize_Herbivores_Min"]),
                     Max= (Biomass_MIS3[,"Biomass_MediumSize_Herbivores_Max"]),
                     Size= "Medium")
Large <- data.frame(Biomass = c(Biomass_MIS3[,"Biomass_Large_Herbivores_Mean"]),
                    Region = (Biomass_MIS3[,"Region"]),
                    Min= (Biomass_MIS3[,"Biomass_Large_Herbivores_Min"]),
                    Max= (Biomass_MIS3[,"Biomass_Large_Herbivores_Max"]),
                    Size= "Large")  

Dataset_Biomass <- rbind(Small, Medium,  Large)
head(Dataset_Biomass)
Dataset_Biomass$Region

# Get summart statistics
df <- group_by(Dataset_Biomass, Region, Size)
df <- dplyr::summarise(df, Biomass = mean(Biomass), Min=mean(Min), Max=mean(Max))
df <- as.data.frame(df)


# Plot

empty_bar <- 4 # Set a number of 'empty bar' to add at the end of each group
to_add <- data.frame( matrix(NA, empty_bar*nlevels(df$Region), ncol(df)) )
colnames(to_add) <- colnames(df)
to_add$Region <- rep(levels(df$Region), each=empty_bar)
df <- rbind(df, to_add)
df <- df %>% arrange(Region)
df$Region1 <- seq(1, nrow(df))

# Get the name and the y position of each label
label_data <- df
number_of_bar <- nrow(label_data)
angle <- 90 - 360 * (label_data$Region1-0.5) /number_of_bar
label_data$hjust <- ifelse( angle < -90, 1, 0)
label_data$angle <- ifelse(angle < -90, angle+180, angle)


Biomass_Plot <- ggplot(df, aes(x=as.factor(Region), y=Biomass, fill=factor(Size, levels=c("Large", "Medium", "Small")))) +       # Note that id is a factor. If x is numeric, there is some space between the first bar
  geom_bar(stat="identity", alpha=0.7) +
  ylim(-150,900) +
  theme_minimal() +
  scale_x_discrete(limits=c( "Danube", "Carpathian", "Ionian" ,"EurosiberianUpperDanube" , "CentralNorthEurope",
                              "Adriatic", "Prealpine","Tyrrhenian", "Ligurian", "MeditFrance", "Aquitane",
                               "Cantabrian", "Supramediterranean", "Mesomediterranean",
                              "Thermomediterranean", "NorthwestEurope"  ))+
  scale_fill_brewer(name="Size", breaks = c("Large", "Medium", "Small"), palette = "Blues")+
  coord_polar() +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    axis.ticks = element_blank(),
    axis.text.y = element_blank(),
    axis.text.x = element_text(face = "bold"),
    plot.title = element_text(size = 12, face = "bold"),
    plot.subtitle = element_text(size =8)
  ) + annotate(
      x = 2.5, 
      y = 200, 
      label = "200", 
      geom = "text", 
      color = "black")+ annotate(
  x = 2.5, 
  y = 400, 
  label = "400", 
  geom = "text", 
  color = "black")+ annotate(
    x = 2.5, 
    y = 600, 
    label = "600", 
    geom = "text", 
    color = "black") + annotate(
  x = 2.5, 
  y = 800, 
  label = "800", 
  geom = "text", 
  color = "black")

Biomass_Plot

